import { useState, useEffect } from 'react'
import { useFetch } from '../../hooks/useFetch'
import { useHistory } from 'react-router-dom'
import SchoolsList from '../../components/SchoolsList'


// styles
import './Create.css'



export default function Create() {  
  const [name, setName] = useState('')
  const [gender, setGender] = useState('')
  const [email, setEmail] = useState('')
  const [schoolGender, setschoolGender] = useState("");
  const [outgoing, setOutgoing] = useState("");

  const Search = (data) => {
    return data.filter(
      (item) => (
        (!schoolGender || item.schoolGender.toLowerCase() === schoolGender) &&
        (!outgoing || item.outgoing.toLowerCase() === outgoing) 
        )
    );
  };

  const { data, isPending, error } = useFetch('http://localhost:3000/schools')


  const { postData, sendData } = useFetch('http://localhost:3600/recipes', 'POST')
  const history = useHistory()
  
  const handleSubmit = (e) => {
    e.preventDefault()
    postData({ name, gender, email,schoolGender,outgoing})
  }


  // redirect the user when we get data response
  useEffect(() => {
    if (sendData) {
      history.push('/')
    }
  }, [sendData, history])

  return (
    <div className="create">
      <h2 className="page-title">学生信息</h2>
      <form onSubmit={handleSubmit}>

        <label>
          <span>学生姓名（name）:</span>
          <input 
            type="text" 
            onChange={(e) => setName(e.target.value)}
            value={name}
            required
          />
        </label>

        <label>
          <span>性别(gender):</span>
          <input
            type="text" 
            onChange={(e) => setGender(e.target.value)}
            value={gender}
          />
        </label>

        <label>
          <span>邮件地址(email):</span>
          <input 
            type="email" 
            onChange={(e) => setEmail(e.target.value)}
            value={email}
          />
        </label>

        <div>
      <p>学校类型选择:</p>
      <fieldset id="gender" onChange={(e) => setschoolGender(e.target.value.toLowerCase())}>
        <input type="radio" name="gender" value="Girl" /> <label>Girl</label>
        <input type="radio" name="gender" value="Boy" /><label>Boy</label>
        <input type="radio" name="gender" value="co" /><label>Mix</label>
      </fieldset>
    </div>

    <div>
      <p>性格:</p>
        <fieldset onChange={(e) => setOutgoing(e.target.value.toLowerCase())}> 
          <input type="radio" name="outgoing" value="in" />内
          <input type="radio" name="outgoing" value="out" />外
        </fieldset> 
     </div>

     <div>
      <p>家庭培养目标:</p>
        <fieldset onChange={(e) => setOutgoing(e.target.value.toLowerCase())}> 
          <input type="radio" name="outgoing" value="in" />内
          <input type="radio" name="outgoing" value="out" />外
        </fieldset> 
     </div>

        <button className="btn">submit</button>
      </form>

      {error && <p className="error">{error}</p>}
      {isPending && <p className="loading">Loading...</p>}
      {data && <SchoolsList data={Search(data)} />}  
    </div>
  )
}
