import { BrowserRouter, Switch, Route } from 'react-router-dom'

// page components
import Navbar from './components/Navbar'
import Home from './pages/home/Home'
import Create from './pages/create/Create'
import Result from './pages/result/Result'
import School from './pages/school/School'

// styles
import './App.css'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navbar />
        <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route path="/create">
            <Create />
          </Route>
          <Route path="/result">
            <Result />
          </Route>
          <Route path="/schools/:id">
            <School />
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App