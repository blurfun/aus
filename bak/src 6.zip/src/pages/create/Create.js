import { useState, useEffect } from 'react'
import { useFetch } from '../../hooks/useFetch'
import { useHistory } from 'react-router-dom'
import SchoolsList from '../../components/SchoolsList'

// styles
import './Create.css'


export default function Create() {
  const [name, setName] = useState('')
  const [domesticGoal, setDomesticGoal] = useState([])
  const [schoolGoal, setSchoolGoal] = useState([])
  const [gender, setGender] = useState('')
  const [email, setEmail] = useState('')
  const [schoolGender, setSchoolGender] = useState([]);
  const [schoolScale, setSchoolScale] = useState([]);
  const [outgoing, setOutgoing] = useState("");
  const [schoolBully, setSchoolBully] = useState([]);

  const Search = (data) => {
    return data.filter(
      (item) =>
        (schoolGender.length === 0 || schoolGender.some((goal) => item.schoolGender.includes(goal)))&&
        (!outgoing || item.outgoing.toLowerCase() === outgoing) &&
        (domesticGoal.length === 0 || domesticGoal.some((goal) => item.domesticGoal.includes(goal)))&&
        (schoolGoal.length === 0 || schoolGoal.some((goal) => item.schoolGoal.includes(goal)))&&
        (schoolScale.length === 0 || schoolScale.some((goal) => item.schoolScale.includes(goal)))&&
        (schoolBully.length === 0 || schoolBully.some((goal) => item.schoolBully.includes(goal)))   
    )
  }

  const { data, isPending, error } = useFetch('http://localhost:3000/schools')
  const { postData } = useFetch('http://localhost:3600/recipes', 'POST')
  const history = useHistory()

  const handleSubmit = (e) => {
    e.preventDefault()
    postData({ name, domesticGoal,schoolGoal,schoolGender,outgoing,schoolScale })
  }

  // redirect the user when we get data response
  useEffect(() => {
    if (data) {
      history.push('/')
    }
  }, [data, history])

  const domesticGoalOptions = [
    { value: 'multicultural', label: '多元化' },
    { value: 'academic', label: '学术性' },
    { value: 'topscore', label: '精英型' },
  ]

  const handleDomesticGoal= (optionValue) => {
    if (domesticGoal.includes(optionValue)) {
      setDomesticGoal(domesticGoal.filter((o) => o !== optionValue))
    } else {
      setDomesticGoal([...domesticGoal, optionValue])
    }
  }

  const schoolGoalOptions = [
    { value: 'competitive', label: '竞争' },
    { value: 'encourage', label: '鼓励' },
    { value: 'care', label: '呵护' },
  ]

  const handleSchoolGoal= (optionValue) => {
    if (schoolGoal.includes(optionValue)) {
      setSchoolGoal(schoolGoal.filter((o) => o !== optionValue))
    } else {
      setSchoolGoal([...schoolGoal, optionValue])
    }
  }


  const schoolScaleOptions = [
    { value: 'small', label: '小学校' },
    { value: 'medium', label: '中等学校' },
    { value: 'large', label: '大学校' },
  ]
  const handleSchoolScale= (optionValue) => {
    if (schoolScale.includes(optionValue)) {
      setSchoolScale(schoolScale.filter((o) => o !== optionValue))
    } else {
      setSchoolScale([...schoolScale, optionValue])
    }
  }


  const schoolGenderOptions = [
    { value: 'girl', label: '女校' },
    { value: 'boy', label: '男校' },
    { value: 'co', label: '混校' },
  ]
  const handleSchoolGender= (optionValue) => {
    if (schoolGender.includes(optionValue)) {
      setSchoolGender(schoolGender.filter((o) => o !== optionValue))
    } else {
      setSchoolGender([...schoolGender, optionValue])
    }
  }


const schoolBullyOptions = [  
  { value: '1', label: '小' },  
  { value: '2', label: '一般' }, 
   { value: '3', label: '严重' },
  ]
const handleSchoolBully= (optionValue) => {
  if (schoolBully.includes(optionValue)) {
    setSchoolBully(schoolBully.filter((o) => o !== optionValue))
  } else {
    setSchoolBully([...schoolBully, optionValue])
  }
}



  return (
    <div className="create">
      <h2 className="page-title">学生信息</h2>
      <form onSubmit={handleSubmit}>
        <label>
          <span>学生姓名（name）:</span>
          <input
            type="text"
            onChange={(e) => setName(e.target.value)}
            value={name}
            required
          />
        </label>

        <label>
          <span>性别(gender):</span>
          <input
            type="text" 
            onChange={(e) => setGender(e.target.value)}
            value={gender}
          />
        </label>

        <label>
          <span>邮件地址(email):</span>
          <input 
            type="email" 
            onChange={(e) => setEmail(e.target.value)}
            value={email}
          />
        </label>

        <div className="more-options">
          <span> 学校性质 </span>
          {schoolGenderOptions.map((option) => (
            <div key={option.value}>
              <label>
                <input
                  type="checkbox"
                  name="schoolGender"
                  value={option.value}
                  checked={schoolGender.includes(option.value)}
                  onChange={() => handleSchoolGender(option.value)}
                />
                {option.label}
              </label>
            </div>
          ))}
      </div>

      <div>
      <p>性格:</p>
        <fieldset onChange={(e) => setOutgoing(e.target.value.toLowerCase())}> 
          <input type="radio" name="outgoing" value="in" />内
          <input type="radio" name="outgoing" value="out" />外
        </fieldset> 
      </div>


      <div className="more-options">
          <span> 家庭培养目标 </span>
          {domesticGoalOptions.map((option) => (
            <div key={option.value}>
              <label>
                <input
                  type="checkbox"
                  name="domesticGoal"
                  value={option.value}
                  checked={domesticGoal.includes(option.value)}
                  onChange={() => handleDomesticGoal(option.value)}
                />
                {option.label}
              </label>
            </div>
          ))}
      </div>


      <div className="more-options">
          <span> 学校培养目标 </span>
          {schoolGoalOptions.map((option) => (
            <div key={option.value}>
              <label>
                <input
                  type="checkbox"
                  name="schoolGoal"
                  value={option.value}
                  checked={schoolGoal.includes(option.value)}
                  onChange={() => handleSchoolGoal(option.value)}
                />
                {option.label}
              </label>
            </div>
          ))}
      </div>

      <div className="more-options">
          <span> 学校规模 </span>
          {schoolScaleOptions.map((option) => (
            <div key={option.value}>
              <label>
                <input
                  type="checkbox"
                  name="schoolScale"
                  value={option.value}
                  checked={schoolScale.includes(option.value)}
                  onChange={() => handleSchoolScale(option.value)}
                />
                {option.label}
              </label>
            </div>
          ))}
      </div>

  <div className="more-options">
  <span> school bully </span>
  {schoolBullyOptions.map((option) => (
    <div key={option.value}>
      <label>
        <input
          type="checkbox"
          name="schoolBully"
          value={option.value}
          checked={schoolBully.includes(option.value)}
          onChange={() => handleSchoolBully(option.value)}
        />
        {option.label}
      </label>
    </div>
    ))}
  </div>

      <button className="btn">submit</button>
      </form>

      {error && <p className="error">{error}</p>}
      {isPending && <p className="loading">Loading...</p>}
      {data && <SchoolsList data={Search(data)} />}
      
       
    </div>
  )
}
