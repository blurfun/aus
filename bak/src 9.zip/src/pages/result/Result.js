
// styles
import './Result.css'


export default function Result() {
  return (
    <div >

          <h1>收到信息</h1>

    </div>
  )
}
