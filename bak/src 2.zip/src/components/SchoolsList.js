import { Link } from 'react-router-dom'

// styles
import './SchoolsList.css'

export default function SchoolsList({ schools }) {

  if (schools.length === 0) {
    return <div className="error">No school to load...</div>
  }

  return (
    <div className="schools-list">
      {schools.map(school => (
        <div key={school.id} className="card">
          <h3>{school.schoolName}</h3>
          <p>{school.cookingTime} to make.</p>
          <div>{school.schoolGender.substring(0, 100)}...</div>
          <Link to={`/schools/${school.id}`}>查看详情</Link>
          
        </div>
      ))}
    </div>
  )
}
