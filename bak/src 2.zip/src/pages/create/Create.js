import { useState, useEffect } from 'react'
import { useFetch } from '../../hooks/useFetch'
import { useHistory } from 'react-router-dom'

// styles
import './Create.css'

export default function Create() {  
  const [name, setName] = useState('')
  const [gender, setGender] = useState('')
  const [email, setEmail] = useState('')

  const { postData, data } = useFetch('http://localhost:3600/recipes', 'POST')
  const history = useHistory()
  
  const handleSubmit = (e) => {
    e.preventDefault()
    postData({ name, gender, email})
  }


  // redirect the user when we get data response
  useEffect(() => {
    if (data) {
      history.push('/')
    }
  }, [data, history])

  return (
    <div className="create">
      <h2 className="page-title">学生信息</h2>
      <form onSubmit={handleSubmit}>

        <label>
          <span>学生姓名（name）:</span>
          <input 
            type="text" 
            onChange={(e) => setName(e.target.value)}
            value={name}
            required
          />
        </label>

        <label>
          <span>性别(gender):</span>
          <input
            type="text" 
            onChange={(e) => setGender(e.target.value)}
            value={gender}
          />
        </label>

        <label>
          <span>邮件地址(email):</span>
          <input 
            type="email" 
            onChange={(e) => setEmail(e.target.value)}
            value={email}
          />
        </label>

        <button className="btn">submit</button>
      </form>
    </div>
  )
}
