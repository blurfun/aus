import { useFetch } from '../../hooks/useFetch'
import SchoolsList from '../../components/SchoolsList'
import Searchbar from '../../components/Searchbar'
import Create from '../create/Create'

// styles
import './Home.css'


export default function Home() {
  const { data, isPending, error } = useFetch('http://localhost:3000/schools')

  return (
    <div className="home">

      <Searchbar />
      <Create />
      {error && <p className="error">{error}</p>}
      {isPending && <p className="loading">Loading...</p>}
      {data && <SchoolsList schools={data} />}
    </div>
  )
}
