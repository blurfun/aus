import { useFetch } from '../../hooks/useFetch'
import SchoolsList from '../../components/SchoolsList'
import Create from '../create/Create'

import {  useState } from "react";

// styles
import './Home.css'


export default function Home() {
  const { data, isPending, error } = useFetch('http://localhost:3000/schools')


  const [gender, setGender] = useState("");
  const [outgoing, setOutgoing] = useState("");

  const Search = (data) => {
    return data.filter(
      (item) => (
        (!gender || item.schoolGender.toLowerCase() === gender) &&
        (!outgoing || item.outgoing.toLowerCase() === outgoing) 
        )
    );
  };

  return (
    <div className="home">

    <div>
      <p>学校类型选择:</p>
      <fieldset id="gender" onChange={(e) => setGender(e.target.value.toLowerCase())}>
        <input type="radio" name="gender" value="Girl" /> <label>Girl</label>
        <input type="radio" name="gender" value="Boy" /><label>Boy</label>
        <input type="radio" name="gender" value="co" /><label>Mix</label>
      </fieldset>
    </div>

    <div>
      <p>性格:</p>
        <fieldset onChange={(e) => setOutgoing(e.target.value.toLowerCase())}> 
          <input type="radio" name="outgoing" value="in" />内
          <input type="radio" name="outgoing" value="out" />外
        </fieldset> 
     </div>

      <Create />
      {error && <p className="error">{error}</p>}
      {isPending && <p className="loading">Loading...</p>}
      {data && <SchoolsList data={Search(data)} />}
      
    </div>
  )
}
